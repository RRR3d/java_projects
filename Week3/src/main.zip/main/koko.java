package main;
public class koko {
}
